﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kişisel_Finans_Takip_Uygulaması
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DataService dataService = new DataService();
            List<Transaction> transactions = dataService.LoadTransactions();

            while (true)
            {
                Console.Clear();
                Console.WriteLine("📊 Kişisel Finans Takip Uygulaması");
                Console.WriteLine("-----------------------------------");
                Console.WriteLine("1 - Gelir Ekle");
                Console.WriteLine("2 - Gider Ekle");
                Console.WriteLine("3 - İşlemleri Listele");
                Console.WriteLine("4 - Toplam Bakiye Görüntüle");
                Console.WriteLine("0 - Çıkış");
                Console.Write("Seçiminiz: ");
                string choice = Console.ReadLine() ?? "";

                switch (choice)
                {
                    case "1":
                        AddTransaction(transactions, "Gelir");
                        dataService.SaveTransactions(transactions);
                        break;

                    case "2":
                        AddTransaction(transactions, "Gider");
                        dataService.SaveTransactions(transactions);
                        break;

                    case "3":
                        ListTransactions(transactions);
                        break;

                    case "4":
                        ShowBalance(transactions);
                        break;

                    case "0":
                        dataService.SaveTransactions(transactions);
                        return;

                    default:
                        Console.WriteLine("Geçersiz seçim!");
                        break;
                }

                Console.WriteLine("\nDevam etmek için bir tuşa basın...");
                Console.ReadKey();
            }
        }
        static void AddTransaction(List<Transaction> transactions, string category)
        {
            Console.Write("Açıklama: ");
            string desc = Console.ReadLine() ?? "";

            Console.Write("Tutar: ");
            decimal amount;
            while (!decimal.TryParse(Console.ReadLine(), out amount))
            {
                Console.Write("Geçerli bir tutar girin: ");
            }

            Transaction t = new Transaction()
            {
                Date = DateTime.Now,
                Description = desc,
                Amount = amount,
                Category = category
            };

            transactions.Add(t);
            Console.WriteLine($"{category} başarıyla eklendi.");
        }
        static void ListTransactions(List<Transaction> transactions)
        {
            Console.WriteLine("\n📑 İşlem Listesi:");
            Console.WriteLine("Tarih       | Tür   |     Tutar | Açıklama");
            Console.WriteLine("-------------------------------------------");
            foreach (var t in transactions)
            {
                Console.WriteLine(t);
            }
        }
        static void ShowBalance(List<Transaction> transactions)
        {
            decimal balance = transactions.Sum(t => t.Category == "Gelir" ? t.Amount : -t.Amount);
            Console.WriteLine($"\n💰 Toplam Bakiye: {balance:C}");
        }
    }
}
