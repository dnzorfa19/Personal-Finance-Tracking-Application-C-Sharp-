﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.IO;


namespace Kişisel_Finans_Takip_Uygulaması
{
    public class DataService
    {
        private string filePath = "transactions.cs";

        public List<Transaction> LoadTransactions()
        {
            if (!File.Exists(filePath))
                return new List<Transaction>();

            string json = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<List<Transaction>>(json) ?? new List<Transaction>();
        }

        public void SaveTransactions(List<Transaction> transactions)
        {
            string json = JsonSerializer.Serialize(transactions, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }
    }
}
